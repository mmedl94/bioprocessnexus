# BioProcessNexus
This package is a tool to facilitate easy sharing and analysis of techno economic process models. 
